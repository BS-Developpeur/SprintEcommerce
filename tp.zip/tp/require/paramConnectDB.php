<?php
define("HOST",     "localhost");
define("USER",     "e1995685");
define("PASSWORD", "U6JiuwdQ5RF5YyHEKiBJ");
define("DBNAME",   "e1995685");